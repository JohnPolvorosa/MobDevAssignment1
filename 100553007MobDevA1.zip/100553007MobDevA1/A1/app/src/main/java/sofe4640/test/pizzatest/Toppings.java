package sofe4640.test.pizzatest;

public class Toppings {

    private String name;
    private int price;

    private int sumPrice = 0;


    public Toppings(String name, int price) {
        this.name = name;
        this.price = price;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    //to show text properly on dropdown
    @Override
    public String toString() {
        return name;
    }


}
