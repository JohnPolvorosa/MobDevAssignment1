package sofe4640.test.pizzatest;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

import java.text.DecimalFormat;

public class ConfirmationPage extends AppCompatActivity {

    public void back (View v)
    {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
        Toast.makeText(this,"Order Cancelled",Toast.LENGTH_LONG).show();
    }

    public void confirm (View v)
    {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
        Toast.makeText(this,"Your Order has been Sent!",Toast.LENGTH_LONG).show();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_confirmation_page);

        Intent intent = getIntent();
        String textName = intent.getStringExtra(MainActivity.EXTRA_NAME);
        String textAddress = intent.getStringExtra(MainActivity.EXTRA_ADDRESS);
        int textNumber = intent.getIntExtra(MainActivity.EXTRA_NUMBER, 0);
        String textEmail = intent.getStringExtra(MainActivity.EXTRA_EMAIL);
        String textSpecial = intent.getStringExtra(MainActivity.EXTRA_SPECIAL);
        int textPrice = intent.getIntExtra(MainActivity.EXTRA_PRICE,0);

        TextView textView1 = (TextView) findViewById(R.id.outputName);
        TextView textView2 = (TextView) findViewById(R.id.outputAddress);
        TextView textView3 = (TextView) findViewById(R.id.outputNumber);
        TextView textView4 = (TextView) findViewById(R.id.outputEmail);
        TextView textView5 = (TextView) findViewById(R.id.outputSpecial);
        TextView textView6 = (TextView) findViewById(R.id.outputPrice);


        textView1.setText(textName);
        textView2.setText(textAddress);
        textView3.setText("" + textNumber);
        textView4.setText(textEmail);
        textView5.setText(textSpecial);
        textView6.setText("$" + textPrice);

    }
}
