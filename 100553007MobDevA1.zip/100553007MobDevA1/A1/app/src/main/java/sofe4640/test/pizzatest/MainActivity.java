package sofe4640.test.pizzatest;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    /*@Override
    //try menu inflater
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.dropdown_menu, menu);
        return true;
    }
     */
    public static final String EXTRA_NAME = "sofe4640.test.pizzatest.EXTRA_TEXT";
    public static final String EXTRA_ADDRESS = "sofe4640.test.pizzatest.EXTA_ADDRESS";
    public static final String EXTRA_NUMBER = "sofe4640.test.pizzatest.EXTA_NUMBER";
    public static final String EXTRA_EMAIL = "sofe4640.test.pizzatest.EXTA_EMAIL";
    public static final String EXTRA_SPECIAL ="sofe4640.test.pizzatest.EXTRA_SPECIAL";

    public static final String EXTRA_PRICE ="sofe4640.test.pizzatest.EXTRA_PRICE";
    int totalprice=0;

    private Spinner myspinner;


    public void openConfirmationPage (View v)
    {
        EditText editText1 = (EditText) findViewById(R.id.inputName);
        String textName = editText1.getText().toString();

        EditText editText2 = (EditText) findViewById(R.id.inputAddress);
        String textAddress = editText2.getText().toString();



        EditText editText4 = (EditText) findViewById(R.id.inputEmail);
        String textEmail = editText4.getText().toString();

        EditText editText5 = (EditText) findViewById(R.id.inputSpecial);
        String textSpecial = editText5.getText().toString();

        EditText editText3 = (EditText) findViewById(R.id.inputPhone);
        int textNumber = Integer.parseInt(editText3.getText().toString());

        TextView textView = (TextView) findViewById(R.id.outputSum);
        int textPrice = Integer.parseInt(textView.getText().toString());
        //double textPrice = Double.parseDouble(textView.getText().toString());


        Intent intent = new Intent(this, ConfirmationPage.class);
        //
        intent.putExtra(EXTRA_NAME, textName);
        intent.putExtra(EXTRA_ADDRESS, textAddress);
        intent.putExtra(EXTRA_NUMBER, textNumber);
        intent.putExtra(EXTRA_EMAIL, textEmail);
        intent.putExtra(EXTRA_SPECIAL, textSpecial);
        intent.putExtra(EXTRA_PRICE, textPrice);


        startActivity(intent);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        TextView textView = (TextView) findViewById(R.id.outputSum);
        textView.setText(String.valueOf(totalprice));

        //RadioButton radioButton1 = (RadioButton)findViewById(R.id.sizeS);
        //radioButton1.setOnClickListener(
        //{

        //}

       // final CheckBox checkbox1 = (CheckBox) findViewById(R.id.extraCheese);
       // if (checkbox1.isChecked()) {
       //     totalprice+=5;
        //    checkbox1.setChecked(false);
       // }

        //create spinner obj
        myspinner = (Spinner)findViewById(R.id.spinner1);
        List<Toppings> toppingsList = new ArrayList<>();

        Toppings toppings1 = new Toppings("Select Topping", 0);
        toppingsList.add(toppings1);
        Toppings toppings2 = new Toppings("Mushroom ($5)", 5);
        toppingsList.add(toppings2);
        Toppings toppings3 = new Toppings("Sun Dried Tomatoes ($5)", 5);
        toppingsList.add(toppings3);
        Toppings toppings4 = new Toppings("Chicken ($7)", 7);
        toppingsList.add(toppings4);
        Toppings toppings5 = new Toppings("Ground Beef ($8)", 8);
        toppingsList.add(toppings5);

        ArrayAdapter<Toppings> adapter = new ArrayAdapter<Toppings>(this,
                android.R.layout.simple_spinner_item, toppingsList);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        myspinner.setAdapter(adapter);

/*
        ArrayAdapter<String> myAdapter = new ArrayAdapter<String>(MainActivity.this,
                android.R.layout.simple_list_item_1, getResources().getStringArray(R.array.options));
        //set adapter as dropdown
        myAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        //allow adapter to show data into spinner
        myspinner.setAdapter(myAdapter);

*/

        myspinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener()
        {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                Toppings toppings = (Toppings) adapterView.getSelectedItem();
                displayData(toppings);

            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

    }

    public void getSelectedTopping(View v)
    {
        Toppings toppings = (Toppings) myspinner.getSelectedItem();
        displayData(toppings);
    }

    private void displayData(Toppings toppings)
    {
        String name = toppings.getName();
        int price = toppings.getPrice();

        int tempSum = ((Integer.valueOf(toppings.getPrice())));
        totalprice+=toppings.getPrice();
        String toppingData = "Topping: " + name + "\nPrice: $" + price;

        //@@@
        //update price
        TextView textView = (TextView) findViewById(R.id.outputSum);
        textView.setText(String.valueOf(totalprice));

        Toast.makeText(this,toppingData,Toast.LENGTH_LONG).show();
    }

    public void addS (View v)
    {
        RadioButton buttonS = (RadioButton)findViewById(R.id.sizeS);
        RadioButton buttonM = (RadioButton) findViewById(R.id.sizeM);
        RadioButton buttonL = (RadioButton) findViewById(R.id.sizeL);
        RadioButton buttonXL = (RadioButton) findViewById(R.id.sizeXL);
        //RadioButton checkS = (CheckBox) findViewById(R.id.sizeS);
        //CheckBox checkDelivery = (CheckBox) findViewById(R.id.extraCheese);
        //CheckBox checkCheese = (CheckBox) findViewById(R.id.delivery);
        //if (checkDelivery.isChecked()) {

        if (buttonS.isChecked())
        {
            totalprice += 5.50;
            TextView textView = (TextView) findViewById(R.id.outputSum);
            textView.setText(String.valueOf(totalprice));
        }
        /*
        while(!(buttonS.isChecked()))
        {
            if (buttonM.isChecked())
            {
                totalprice += 7.99;
                TextView textView = (TextView) findViewById(R.id.outputSum);
                textView.setText(String.valueOf(totalprice));
            }
            else if (buttonL.isChecked())
            {
                totalprice += 9.50;
                TextView textView = (TextView) findViewById(R.id.outputSum);
                textView.setText(String.valueOf(totalprice));
            }
            else if (buttonXL.isChecked())
            {
                totalprice += 11.38;
                TextView textView = (TextView) findViewById(R.id.outputSum);
                textView.setText(String.valueOf(totalprice));
            }


        }
        */
        else if (!(buttonS.isChecked()))
        {
            totalprice -= 5.50;
            TextView textView = (TextView) findViewById(R.id.outputSum);
            textView.setText(String.valueOf(totalprice));
        } //CHECK NEXT SIZE
        else if (buttonM.isChecked())
        {
            totalprice += 7.99;
            TextView textView = (TextView) findViewById(R.id.outputSum);
            textView.setText(String.valueOf(totalprice));
        } else if (!(buttonM.isChecked()))
        {
            totalprice -= 7.99;
            TextView textView = (TextView) findViewById(R.id.outputSum);
            textView.setText(String.valueOf(totalprice));
        } //CHECK NEXT SIZE
        else if (buttonL.isChecked())
        {
            totalprice += 9.50;
            TextView textView = (TextView) findViewById(R.id.outputSum);
            textView.setText(String.valueOf(totalprice));
        } else if (!(buttonL.isChecked()))
        {
            totalprice -= 9.50;
            TextView textView = (TextView) findViewById(R.id.outputSum);
            textView.setText(String.valueOf(totalprice));
        } //CHECK NEXT SIZE
        else if (buttonXL.isChecked())
        {
            totalprice += 11.38;
            TextView textView = (TextView) findViewById(R.id.outputSum);
            textView.setText(String.valueOf(totalprice));
        } else if (!(buttonXL.isChecked()))
        {
            totalprice -= 11.38;
            TextView textView = (TextView) findViewById(R.id.outputSum);
            textView.setText(String.valueOf(totalprice));
        }


    }


    public void addM (View v)
    {
        totalprice+=7.99;
        TextView textView = (TextView) findViewById(R.id.outputSum);
        textView.setText(String.valueOf(totalprice));
    }

    public void addL (View v)
    {
        totalprice+=9.50;
        TextView textView = (TextView) findViewById(R.id.outputSum);
        textView.setText(String.valueOf(totalprice));
    }
    public void addXL (View v)
    {
        totalprice+=11.38;
        TextView textView = (TextView) findViewById(R.id.outputSum);
        textView.setText(String.valueOf(totalprice));
    }
    public void add5 (View v)
    {

        CheckBox checkDelivery = (CheckBox) findViewById(R.id.extraCheese);
        CheckBox checkCheese = (CheckBox) findViewById(R.id.delivery);

        if (checkDelivery.isChecked()) {
            totalprice += 5;
            TextView textView = (TextView) findViewById(R.id.outputSum);
            textView.setText(String.valueOf(totalprice));
        } else if (checkCheese.isChecked()) {
            totalprice += 5;
            TextView textView = (TextView) findViewById(R.id.outputSum);
            textView.setText(String.valueOf(totalprice));
        } else if (!(checkDelivery.isChecked()))
        {
            totalprice -=5;
            TextView textView = (TextView) findViewById(R.id.outputSum);
            textView.setText(String.valueOf(totalprice));
        } else if (!(checkCheese.isChecked()))
        {
            totalprice -=5;
            TextView textView = (TextView) findViewById(R.id.outputSum);
            textView.setText(String.valueOf(totalprice));
        }
        {
            //totalprice -=5;
        }
    }

    public void checkSub (View v)
    {
        CheckBox checkDelivery = (CheckBox) findViewById(R.id.extraCheese);
        CheckBox checkCheese = (CheckBox) findViewById(R.id.delivery);
        if (!(checkDelivery.isChecked()))
        {
            totalprice -=5;
            TextView textView = (TextView) findViewById(R.id.outputSum);
            textView.setText(String.valueOf(totalprice));
        }

    }

    //@Override

    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
        String text1 = adapterView.getItemAtPosition(i).toString();
        Toast.makeText(adapterView.getContext(), text1,Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }


}
